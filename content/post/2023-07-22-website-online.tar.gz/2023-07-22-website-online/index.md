---
title: The Pitt Intelligent Systems Lab website is now online
date: 2023-07-22
image:
  focal_point: 'top'
authors:
  - boyuan
---

The website for Pitt Intelligent System Lab is now online.

<!--more-->

The current website URL for Intelligent Systems Lab at University of Pittsburgh is https://pittisl.github.io.
